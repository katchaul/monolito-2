<?php

namespace App\Http\Controllers;

use App\Models\professores;
use App\Http\Requests\StoreprofessoresRequest;
use App\Http\Requests\UpdateprofessoresRequest;

class ProfessoresController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreprofessoresRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(professores $professores)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(professores $professores)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateprofessoresRequest $request, professores $professores)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(professores $professores)
    {
        //
    }
}
