<?php

namespace App\Http\Controllers;

use App\Models\enderecos;
use App\Http\Requests\StoreenderecosRequest;
use App\Http\Requests\UpdateenderecosRequest;

class EnderecosController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreenderecosRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(enderecos $enderecos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(enderecos $enderecos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateenderecosRequest $request, enderecos $enderecos)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(enderecos $enderecos)
    {
        //
    }
}
